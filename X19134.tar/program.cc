#include "LlistaIOParInt.hh"
#include <iostream>
#include <list>

int main() {
	int n;
	list<ParInt> l;
	LlegirLlistaParInt(l);
	list<ParInt>::const_iterator it = l.begin();
	
	cin >> n;
	cout << n << " ";
	
	int count = 0;
	int sum = 0;
	while (it != l.end()) {
		if ((*it).primer() == n)  {
			count++; 
			sum += (*it).segon();
		}
		++it;
	}
	cout << count << " " << sum << endl;
}
