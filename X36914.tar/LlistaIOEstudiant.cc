#include "LlistaIOEstudiant.hh"

void LlegirLlistaEstudiant(list<Estudiant>& l)
{
	int dni;
	double nota;
	Estudiant est;
	list<Estudiant>::iterator it = l.end();
	while (cin >> dni >> nota && (dni != 0 && nota != 0)){
		Estudiant est(dni);
		est.afegir_nota(nota);
		l.insert(it,est);
	}
}


void EscriureLlistaEstudiant(const list<Estudiant>& l)
{
	if (not l.empty()) {
    list<Estudiant>::const_iterator it;
    for (it = l.begin(); it != l.end(); ++it){
      it->escriure(); 
    }
  } 
  cout << endl;
}
