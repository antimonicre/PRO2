#include "LlistaIOEstudiant.hh"
#include "Estudiant.hh"
#include <iostream>
#include <list>

int main() {
	int dni;
	list<Estudiant> l;
	LlegirLlistaEstudiant(l);
	list<Estudiant>::const_iterator it = l.begin();
	
	cin >> dni;
	cout << dni << " ";
	
	int count = 0;
	while (it != l.end()) {
		if ((*it).consultar_DNI() == dni)  {
			count++;
		}
		++it;
	}
	cout << count << endl;
}
