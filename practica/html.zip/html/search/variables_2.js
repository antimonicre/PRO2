var searchData=
[
  ['id',['id',['../class_idioma.html#a190992e3323520e1f9562539198904d1',1,'Idioma']]]
];
