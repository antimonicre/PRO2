var searchData=
[
  ['frecuencia',['frecuencia',['../class_tabla_frec.html#a79a57739a487c37acb025eaccfe7be86',1,'TablaFrec']]]
];
