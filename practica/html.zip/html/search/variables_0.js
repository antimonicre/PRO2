var searchData=
[
  ['caracter',['caracter',['../class_tabla_frec.html#abf040edd6313c6b0b204688c174e3bbf',1,'TablaFrec']]],
  ['codigo',['codigo',['../class_idioma.html#a5b440587e5ec408bb6119ae535b3fdc9',1,'Idioma']]],
  ['codigos',['codigos',['../class_idioma.html#a5e4006f678f93f026a79ce00da3f9434',1,'Idioma']]]
];
