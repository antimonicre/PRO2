var searchData=
[
  ['tabla',['tabla',['../class_tabla_frec.html#aef57fd5905c0deed232a4e46640d6ee9',1,'TablaFrec']]],
  ['tablafrec',['tablafrec',['../class_idioma.html#ad2bbd01f165d938981acf52f12683c00',1,'Idioma']]],
  ['treecode',['treecode',['../class_idioma.html#a89972a60a04aa7ab73025c479ddd189b',1,'Idioma']]]
];
