var searchData=
[
  ['size',['size',['../class_tabla_frec.html#ae0dd809ddafcccd9986f2be786a7d077',1,'TablaFrec']]]
];
